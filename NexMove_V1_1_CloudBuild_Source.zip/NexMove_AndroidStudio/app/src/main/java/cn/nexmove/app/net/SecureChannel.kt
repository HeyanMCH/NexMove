package cn.nexmove.app.net

import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Encrypted framed protocol. One-time 256-bit QR key; HKDF-SHA256; independent keys/nonces per direction. */
class SecureChannel private constructor(
    private val input: DataInputStream, private val output: DataOutputStream,
    private val rxKey: ByteArray, private val txKey: ByteArray,
    private val rxPrefix: Int, private val txPrefix: Int
) {
    private var txSeq = 0L
    private var rxSeq = 0L

    @Synchronized fun send(bytes: ByteArray) {
        require(bytes.size <= MAX_PLAINTEXT) { "Frame too large" }
        val nonce = nonce(txPrefix, txSeq++)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(txKey, "AES"), GCMParameterSpec(128, nonce))
        val encrypted = cipher.doFinal(bytes)
        output.writeInt(encrypted.size)
        output.write(encrypted)
        output.flush()
    }

    @Synchronized fun recv(): ByteArray {
        val size = input.readInt()
        if (size < 16 || size > MAX_PLAINTEXT + 16) throw IOException("Invalid frame length: $size")
        val encrypted = ByteArray(size)
        input.readFully(encrypted)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(rxKey, "AES"), GCMParameterSpec(128, nonce(rxPrefix, rxSeq++)))
        return cipher.doFinal(encrypted)
    }

    fun sendJson(value: JSONObject) = send(value.toString().toByteArray(Charsets.UTF_8))
    fun recvJson(): JSONObject = JSONObject(String(recv(), Charsets.UTF_8))

    companion object {
        const val PORT = 45454
        const val MAX_PLAINTEXT = 128 * 1024
        val random = SecureRandom()
        fun randomSecret(): ByteArray = ByteArray(32).also(random::nextBytes)
        private fun nonce(prefix: Int, seq: Long): ByteArray = ByteArray(12).also {
            for (i in 0..3) it[i] = (prefix ushr (24 - i * 8)).toByte()
            for (i in 0..7) it[i + 4] = (seq ushr (56 - i * 8)).toByte()
        }
        /** A minimal HKDF-SHA256 extract + expand, parameterized by unique client/server nonces. */
        private fun hkdf(ikm: ByteArray, salt: ByteArray, info: String): ByteArray {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(salt, "HmacSHA256"))
            val prk = mac.doFinal(ikm)
            mac.init(SecretKeySpec(prk, "HmacSHA256"))
            return mac.doFinal(info.toByteArray(Charsets.UTF_8) + byteArrayOf(1))
        }
        fun client(input: InputStream, output: OutputStream, key: ByteArray): SecureChannel {
            require(key.size == 32)
            val i = DataInputStream(input); val o = DataOutputStream(output)
            o.write(byteArrayOf(78, 88, 77, 49)); val clientNonce = ByteArray(16).also(random::nextBytes)
            o.write(clientNonce); o.flush()
            val serverNonce = ByteArray(16); i.readFully(serverNonce)
            val salt = MessageDigest.getInstance("SHA-256").digest(clientNonce + serverNonce)
            return SecureChannel(i, o, hkdf(key, salt, "NexMove/v1/client"), hkdf(key, salt, "NexMove/v1/server"), 0x4e585332, 0x4e585331)
                .also { it.sendJson(JSONObject().put("type", "hello")); require(it.recvJson().optString("type") == "ready") }
        }
        fun server(input: InputStream, output: OutputStream, key: ByteArray): SecureChannel {
            require(key.size == 32)
            val i = DataInputStream(input); val o = DataOutputStream(output)
            val magic = ByteArray(4); i.readFully(magic)
            if (!magic.contentEquals(byteArrayOf(78, 88, 77, 49))) throw IOException("Wrong protocol")
            val clientNonce = ByteArray(16); i.readFully(clientNonce)
            val serverNonce = ByteArray(16).also(random::nextBytes)
            o.write(serverNonce); o.flush()
            val salt = MessageDigest.getInstance("SHA-256").digest(clientNonce + serverNonce)
            return SecureChannel(i, o, hkdf(key, salt, "NexMove/v1/server"), hkdf(key, salt, "NexMove/v1/client"), 0x4e585331, 0x4e585332)
                .also { require(it.recvJson().optString("type") == "hello"); it.sendJson(JSONObject().put("type", "ready")) }
        }
        fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
    }
}
