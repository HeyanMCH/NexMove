# NexMove 云端编译（只用手机）

当前压缩包是 Android Studio **源码工程**，不是 APK。暂时未在实际 Android SDK 下编译通过，运行 GitHub Actions 时可能需要修复编译错误。

## 云端编译方式

1. 在手机浏览器登录 https://github.com/new ，新建一个**私人仓库**，例如 `NexMove`。
2. 允许 ChatGPT 已连接的 GitHub 应用访问这个仓库，然后把仓库链接发到当前对话；如 `https://github.com/你的用户名/NexMove`。可以让 ChatGPT 帮助把源码和 `.github/workflows/build-apk.yml` 上传进去。
3. 进入仓库 → Actions → `Build NexMove APK` → `Run workflow`。
4. 构建通过后，点开本次运行，在 Artifacts 下下载 `NexMove-v1-debug-APK.zip`，解压后得到 `app-debug.apk`。
5. 两台 Android 手机装**同一个** APK，首次安装若有系统提示需要手动允许。

注意：GitHub 的 Actions 可能受仓库权限、账单和使用额度约束。仓库源码不包含你的手机实际相册、联系人或个人数据；但不要上传个人真实备份或配对码。

## 编译配置

- GitHub Actions: Ubuntu, JDK 17, Android SDK 35, Gradle 8.11.1
- Kotlin 2.1.20, Android Gradle Plugin 8.9.2
- APK 类型：**debug**（调试签名，不适合上架；每次不同构建环境生成的调试签名可能变化）
- 安装兼容目标：Android 8.0（API 26）及以上；最高目标为 API 35，Android 17 的实际兼容性尚未验证

## 安全

默认只通过同一局域网连接；不依赖 Root；不迁移应用私有数据或登录状态。保存原设备数据，先以少量文件和测试联系人验证再批量迁移。
