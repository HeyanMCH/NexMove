package cn.nexmove.app.data

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import org.json.JSONObject
import java.io.File

/** Uses standard PackageInstaller, including split APKs. Explicit system confirmation required. */
object AppInstaller {
    private const val ROOT = "received_apks"
    fun appDir(context: Context, pkg: String): File {
        require(Regex("[a-zA-Z0-9_.]{3,200}").matches(pkg) && pkg.contains('.'))
        return File(context.filesDir, "$ROOT/$pkg").also { it.mkdirs() }
    }
    fun received(context: Context): List<Pair<String, File>> {
        val root = File(context.filesDir, ROOT)
        return root.listFiles().orEmpty().filter { it.isDirectory && File(it, "base.apk").exists() && File(it, "complete.flag").exists() }
            .map { dir ->
                val info = runCatching { JSONObject(File(dir, "meta.json").readText()) }.getOrNull()
                (info?.optString("label")?.takeIf { it.isNotBlank() } ?: dir.name) to dir
            }.sortedBy { it.first.lowercase() }
    }
    fun saveMeta(dir: File, label: String) = File(dir, "meta.json").writeText(JSONObject().put("label", label).toString())

    fun install(context: Context, dir: File) {
        val pm = context.packageManager
        if (Build.VERSION.SDK_INT >= 26 && !pm.canRequestPackageInstalls()) {
            context.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            throw IllegalStateException("请允许 NexMove 安装未知应用，然后再次点击安装")
        }
        val files = dir.listFiles().orEmpty().filter { it.extension == "apk" }.sortedBy { if (it.name == "base.apk") 0 else 1 }
        check(files.any { it.name == "base.apk" }) { "Missing base.apk" }
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED)
        val installer = pm.packageInstaller
        val id = installer.createSession(params)
        try {
            installer.openSession(id).use { session ->
                for (file in files) {
                    session.openWrite(file.name, 0, file.length()).use { destination ->
                        file.inputStream().use { it.copyTo(destination, 64 * 1024) }
                        session.fsync(destination)
                    }
                }
                val intent = Intent(context, InstallResultReceiver::class.java).putExtra("package_dir", dir.name)
                // PackageInstaller adds EXTRA_STATUS to this IntentSender. Android 15+ requires MUTABLE.
                val pending = PendingIntent.getBroadcast(context, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                session.commit(pending.intentSender)
            }
        } catch (e: Exception) {
            runCatching { installer.abandonSession(id) }
            throw e
        }
    }
}

class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                else intent.getParcelableExtra(Intent.EXTRA_INTENT)
                confirm?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let(context::startActivity)
            }
            PackageInstaller.STATUS_SUCCESS -> {
                Log.i("NexMove", "Installed ${intent.getStringExtra("package_dir")}")
                cn.nexmove.app.service.TransferHub.notice("应用安装成功：${intent.getStringExtra("package_dir")}")
            }
            else -> {
                val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "未知错误"
                cn.nexmove.app.service.TransferHub.notice("安装失败：$message")
            }
        }
    }
}
