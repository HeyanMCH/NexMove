@echo off
setlocal
cd /d "%~dp0"
set "WRAPPER=gradle\wrapper\gradle-wrapper.jar"
if not exist "%WRAPPER%" (
  echo Downloading Gradle 8.11.1 official wrapper from github.com/gradle/gradle ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.11.1/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle\wrapper\gradle-wrapper.jar'"
  if errorlevel 1 exit /b 1
)
java -cp "%WRAPPER%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
