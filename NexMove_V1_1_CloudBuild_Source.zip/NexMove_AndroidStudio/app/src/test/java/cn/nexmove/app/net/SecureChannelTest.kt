package cn.nexmove.app.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertArrayEquals
import org.junit.Test
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class SecureChannelTest {
    @Test fun bidirectionalEncryptionAndHandshake() {
        val key = SecureChannel.randomSecret()
        val clientIn = PipedInputStream(1024 * 1024)
        val serverOut = PipedOutputStream(clientIn)
        val serverIn = PipedInputStream(1024 * 1024)
        val clientOut = PipedOutputStream(serverIn)
        val pool = Executors.newFixedThreadPool(2)
        try {
            val server = pool.submit<Unit> {
                val channel = SecureChannel.server(serverIn, serverOut, key)
                assertEquals("ping", String(channel.recv()))
                channel.send("pong".toByteArray())
            }
            val client = pool.submit<Unit> {
                val channel = SecureChannel.client(clientIn, clientOut, key)
                channel.send("ping".toByteArray())
                assertEquals("pong", String(channel.recv()))
            }
            server.get(5, TimeUnit.SECONDS)
            client.get(5, TimeUnit.SECONDS)
        } finally {
            pool.shutdownNow()
            clientIn.close(); clientOut.close(); serverIn.close(); serverOut.close()
        }
    }
}
