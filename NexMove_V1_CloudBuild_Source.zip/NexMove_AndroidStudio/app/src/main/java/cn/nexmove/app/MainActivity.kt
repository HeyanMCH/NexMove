package cn.nexmove.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import cn.nexmove.app.data.AppEntry
import cn.nexmove.app.data.AppInstaller
import cn.nexmove.app.data.DeviceData
import cn.nexmove.app.service.TransferHub
import cn.nexmove.app.service.TransferService
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { NexMoveUi(this) }
    }
}

private val accent = Color(0xFF276BE8)

@Composable
fun NexMoveUi(activity: ComponentActivity) {
    val context = activity.applicationContext
    var screen by remember { mutableStateOf("home") }
    var photos by remember { mutableStateOf(true) }
    var videos by remember { mutableStateOf(true) }
    var contacts by remember { mutableStateOf(true) }
    var manualCode by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var scannedApps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    val selectedApps = remember { mutableStateListOf<String>() }
    val status by TransferHub.status.collectAsState()
    val coroutine = rememberCoroutineScope()
    var received by remember { mutableStateOf<List<Pair<String, java.io.File>>>(emptyList()) }
    fun refreshReceived() { received = AppInstaller.received(context) }

    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) { pending?.invoke() } else message = "部分权限未授权，请在系统设置中允许后重试（可取消不需要迁移的类别）"
        pending = null
    }
    fun withPermissions(permissions: Array<String>, action: () -> Unit) {
        val required = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (required.isEmpty()) action() else { pending = action; permissionLauncher.launch(required.toTypedArray()) }
    }
    fun receiverPermissions() = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)
    fun senderPermissions(): Array<String> {
        val permissions = mutableListOf<String>()
        if (contacts) permissions += Manifest.permission.READ_CONTACTS
        if (photos || videos) {
            if (Build.VERSION.SDK_INT >= 33) {
                if (photos) permissions += Manifest.permission.READ_MEDIA_IMAGES
                if (videos) permissions += Manifest.permission.READ_MEDIA_VIDEO
            } else permissions += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return permissions.toTypedArray()
    }
    fun startReceive() = withPermissions(receiverPermissions()) {
        TransferService.start(context, Intent(context, TransferService::class.java).setAction(TransferService.RECEIVE))
        message = "正在等待建立接收端…"
    }
    fun startSend(pairing: String) {
        if (!(photos || videos || contacts || selectedApps.isNotEmpty())) { message = "至少选择一种数据"; return }
        withPermissions(senderPermissions()) {
            val intent = Intent(context, TransferService::class.java).setAction(TransferService.SEND)
                .putExtra("pairing", pairing.trim()).putExtra("photos", photos)
                .putExtra("videos", videos).putExtra("contacts", contacts)
                .putStringArrayListExtra("apps", ArrayList(selectedApps))
            TransferService.start(context, intent)
            message = "正在建立加密连接…"
        }
    }
    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { result ->
        if (result.contents != null) { manualCode = result.contents; startSend(manualCode) }
    }
    LaunchedEffect(screen) {
        if (screen == "send") scannedApps = withContext(Dispatchers.IO) { DeviceData.apps(context) }
        if (screen == "receive") refreshReceived()
    }
    LaunchedEffect(status.completed, status.message) { if (screen == "receive") refreshReceived() }

    MaterialTheme(colorScheme = lightColorScheme(primary = accent, surface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F7FC)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (screen != "home") TextButton(onClick = { screen = "home" }) { Text("← 返回") }
                    Spacer(Modifier.weight(1f))
                    Text("NexMove · 星迁", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                Text("私密迁移 · 无云端 · 不需要 ROOT", color = Color.Gray, fontSize = 13.sp)
                when (screen) {
                    "home" -> {
                        Panel {
                            Text("把旧手机带到新手机", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("同一个 APK 安装在两台 Android 手机上。连接同一个局域网，旧 OPPO 选择发送，新 Ace 3 选择接收。", color = Color.DarkGray)
                            Button(onClick = { screen = "send" }, modifier = Modifier.fillMaxWidth()) { Text("我是旧手机 · 发送数据") }
                            OutlinedButton(onClick = { screen = "receive" }, modifier = Modifier.fillMaxWidth()) { Text("我是新手机 · 接收数据") }
                        }
                        Panel {
                            Text("V1 支持", fontWeight = FontWeight.Bold)
                            Text("照片 / 视频 · 联系人 · 已安装的用户应用（含 split APK）")
                            Text("不迁移应用私有数据、登录状态、聊天记录；不会删除旧手机数据。", fontSize = 13.sp, color = Color.Gray)
                        }
                    }
                    "send" -> {
                        Panel {
                            Text("1 · 选择要发送的内容", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            SwitchRow("照片", photos) { photos = it }
                            SwitchRow("视频", videos) { videos = it }
                            SwitchRow("联系人（姓名、电话、邮箱）", contacts) { contacts = it }
                            Text("应用 APK（不包含应用登录信息）", fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { selectedApps.clear(); selectedApps.addAll(scannedApps.map { it.packageName }) }) { Text("全选") }
                                TextButton(onClick = { selectedApps.clear() }) { Text("全不选") }
                                Text("已选 ${selectedApps.size}/${scannedApps.size}", modifier = Modifier.align(Alignment.CenterVertically), fontSize = 12.sp)
                            }
                            OutlinedTextField(value = filter, onValueChange = { filter = it }, label = { Text("搜索 App") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth())
                            Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                                scannedApps.filter { filter.isBlank() || it.label.contains(filter, true) || it.packageName.contains(filter, true) }
                                    .forEach { app ->
                                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = app.packageName in selectedApps, onCheckedChange = { checked ->
                                                if (checked && app.packageName !in selectedApps) selectedApps.add(app.packageName)
                                                if (!checked) selectedApps.remove(app.packageName)
                                            })
                                            Column {
                                                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(app.packageName, fontSize = 11.sp, color = Color.Gray)
                                            }
                                        }
                                    }
                            }
                        }
                        Panel {
                            Text("2 · 扫描新手机二维码", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Button(onClick = {
                                scanLauncher.launch(ScanOptions().setPrompt("扫描 NexMove 接收手机的二维码")
                                    .setDesiredBarcodeFormats(ScanOptions.QR_CODE).setBeepEnabled(false))
                            }, modifier = Modifier.fillMaxWidth()) { Text("扫码配对并开始发送") }
                            OutlinedTextField(manualCode, { manualCode = it }, label = { Text("或粘贴接收手机配对码") },
                                modifier = Modifier.fillMaxWidth(), minLines = 2)
                            OutlinedButton(onClick = { startSend(manualCode) }, modifier = Modifier.fillMaxWidth()) { Text("使用配对码发送") }
                        }
                    }
                    "receive" -> {
                        Panel {
                            Text("1 · 在新手机启动接收", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("连接相同 Wi-Fi；如果旧 OPPO 没有网络，可以让其中一台开热点。部分校园 Wi-Fi 隔离客户端，请使用手机热点。", fontSize = 13.sp)
                            Button(onClick = { startReceive() }, modifier = Modifier.fillMaxWidth(), enabled = status.mode != "receive" || status.pairing.isEmpty()) {
                                Text("开始接收 / 生成二维码")
                            }
                            if (status.mode == "receive" && status.pairing.isNotBlank()) {
                                val bitmap = remember(status.pairing) { qrBitmap(status.pairing) }
                                Image(bitmap.asImageBitmap(), "配对二维码", modifier = Modifier.align(Alignment.CenterHorizontally).size(240.dp))
                                Text("用旧手机扫描此二维码", modifier = Modifier.align(Alignment.CenterHorizontally))
                                OutlinedTextField(status.pairing, {}, readOnly = true, label = { Text("备用配对码（内含密钥，不要公开）") },
                                    modifier = Modifier.fillMaxWidth())
                            }
                        }
                        Panel {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("2 · 已接收应用", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { refreshReceived() }) { Text("刷新") }
                            }
                            Text("应用传输完毕后点击安装，系统将要求逐个确认。", fontSize = 13.sp, color = Color.Gray)
                            if (received.isEmpty()) Text("暂无已完成传输的 APK", color = Color.Gray)
                            received.forEach { (label, dir) ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(label, modifier = Modifier.weight(1f), maxLines = 2)
                                    TextButton(onClick = {
                                        coroutine.launch {
                                            runCatching { withContext(Dispatchers.IO) { AppInstaller.install(activity, dir) } }
                                                .onFailure { message = it.message ?: "无法安装" }
                                        }
                                    }) { Text("安装") }
                                }
                            }
                        }
                    }
                }
                Panel {
                    Text("传输状态", fontWeight = FontWeight.Bold)
                    Text(status.message)
                    Text("已处理 ${status.completed} 项 · 错误 ${status.errors}", fontSize = 12.sp, color = Color.Gray)
                    if (message.isNotBlank()) Text(message, color = Color(0xFFB34922), fontSize = 13.sp)
                    if (status.mode != "idle") OutlinedButton(onClick = {
                        // Stop service even while receiving or sending.
                        activity.startService(Intent(context, TransferService::class.java).setAction(TransferService.CANCEL))
                    }, modifier = Modifier.fillMaxWidth()) { Text("停止本次传输") }
                }
                Text("首次测试先选少量文件和 1 个 App。迁移结束前请保留旧机所有数据。", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Surface(shadowElevation = 1.dp, color = Color.White, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}
@Composable private fun SwitchRow(label: String, value: Boolean, toggle: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = toggle)
    }
}
private fun qrBitmap(text: String): Bitmap {
    val size = 512
    val matrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
        val colors = IntArray(size * size)
        for (y in 0 until size) for (x in 0 until size) colors[y * size + x] =
            if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE
        setPixels(colors, 0, size, 0, 0, size, size)
    }
}
