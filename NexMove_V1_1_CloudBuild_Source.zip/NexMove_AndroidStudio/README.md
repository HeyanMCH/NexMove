# NexMove 星迁 — Android Studio 源码项目（V1）

**当前版本：** V1.1（含可选自动临时热点，尚需各厂商真机验证）。

**用途：** 一台无 ROOT 的 OPPO（发送） → 一加 Ace 3 / PixelOS 17（接收），同时支持其他 Android 手机。两端安装同一个 APK，不依赖 Google 服务、ColorOS 服务、登录、云端或 ROOT。

> 这是第一版源码项目（功能实现版），**不是已经在你的两部真机上编译、安装并完成端到端测试的正式发行版**。目前环境没有 Android SDK 和 Gradle 缓存，无法在此生成或验证可运行 APK。必须先用 Android Studio 编译并做双机实测，切勿以它作为唯一备份。

## 已实现

- **照片/视频：** 从发送机 MediaStore 枚举，按选择传输；在接收机保存到 `Pictures/NexMove` 或 `Movies/NexMove`，由系统相册索引。
- **联系人：** 复制姓名、多个手机号、多个邮箱；在接收机写入本地联系人。优先按首个电话号码跳过重复项。V1 不包括头像、生日、社交资料、联系人组等扩展字段。
- **已安装用户 App：** 从普通第三方 App 的 `sourceDir` 和 `splitSourceDirs` 提取全部 APK；在接收端私有存储中保存完整 APK 组，通过标准 Android `PackageInstaller.Session` 安装，每个应用须按系统提示确认。**不复制 App 内部数据、登录状态或微信聊天记录。** 部分保护/系统内置应用不可导出；不同架构和签名也可能使 APK 安装失败。
- **安全：** 同 Wi-Fi / 热点局域网连接；扫码短期随机 256-bit 密钥；交换随机数并用 HKDF 派生独立 AES-256-GCM 密钥，逐帧认证加密；SHA-256 验证每个文件，收错的媒体项删除。
- **后台：** 运行时使用 Android `dataSync` 前台服务和常驻通知。推荐两台手机保持屏幕亮起，不要切换网络。
- **无 ROOT：** 两端均可运行，无需提权；不调用 KSU。无需中国厂商云服务。

## 导入与编译（Windows）

1. 安装 Android Studio，以及 SDK Platform **35**、Android SDK Build-Tools 和 JDK 17/21（Android Studio 通常自带 JDK）。
2. 解压整个目录到无特殊权限限制的路径，如 `D:\Android\NexMove`。
3. 本压缩包没有预置第三方 Gradle 包装器二进制（为了不附带未核验的 JAR）。在网络可用的 PowerShell / CMD 里 **先执行**：

   ```bat
   cd /d D:\Android\NexMove
   gradlew.bat --version
   ```

   `gradlew.bat` 会从 Gradle 官方 GitHub 源代码仓库的 `v8.11.1` 标签首次下载官方 `gradle-wrapper.jar`，再从 Gradle 官网下载 Gradle 8.11.1 发行包。请按需使用代理或自己安装并配置经过验证的 Gradle Wrapper。
4. Android Studio → **Open** → 选择 `NexMove` 项目根目录 → 等待 Gradle Sync，安装依赖。
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)`，产物在 `app/build/outputs/apk/debug/app-debug.apk`。
6. 把同一 APK 装到 OPPO 和 Ace 3，上机逐项授予权限。

**技术版本：** Kotlin 2.1.20、Android Gradle Plugin 8.9.2、Gradle 8.11.1、Jetpack Compose BOM 2025.02.00；`minSdk=26`（Android 8.0）、`targetSdk=35`。Android 17 接收端适用，但需实测。若 Android Studio 推荐升级插件，请先保留工程备份。

## 两机操作

1. 在旧 OPPO 上打开 NexMove → **我是旧手机 · 发送数据**；选择相册、视频、联系人及需要的 App（默认不全选 App，以免误传大量 APK）。
2. 在一加 Ace 3 上打开 NexMove → **我是新手机 · 接收数据** → 允许联系人权限 → **开始接收**，屏幕会出现二维码和配对码。
3. 确保两机连接同一 Wi-Fi，或者用一台手机开热点另一台加入。如果校园 Wi-Fi 隔离终端，改用手机热点。
4. 旧 OPPO 点击 **扫码配对并开始发送**，授予相册/联系人读取权限。手机会发送加密数据，接收端逐个确认校验；不需要 ROOT。
5. 完成后在新手机相册、联系人检查结果；到 NexMove 接收端的 **已接收应用** 列表点 **安装**，按 Android 安装确认。首次可能需要允许 NexMove 安装未知应用；允许后重新点击安装。
6. 在新机逐个登录 App。确认数据正确之前 **不要清空旧 OPPO**。

## 权限与发布提示

| 权限 | 目的 |
| --- | --- |
| INTERNET / ACCESS_NETWORK_STATE / ACCESS_WIFI_STATE | 本地局域网 Socket 和 IP 检测 |
| READ_MEDIA_IMAGES / READ_MEDIA_VIDEO / READ_EXTERNAL_STORAGE | 读取发送手机相册（按 Android 版本申请） |
| READ_CONTACTS / WRITE_CONTACTS | 从旧机读取、向新机导入联系人 |
| QUERY_ALL_PACKAGES | 枚举用户安装的 App 供迁移选择；属于 Google Play 严格限制权限，只建议个人侧载，若上架需要符合商店政策 |
| REQUEST_INSTALL_PACKAGES | 通过系统安装器在新手机安装收到的 APK |
| CAMERA | 扫描二维码 |
| FOREGROUND_SERVICE_DATA_SYNC / POST_NOTIFICATIONS | 前台传输服务及通知 |

本程序未启用 Root；接收端的 ROOT 不被使用。只有用户手动选择的数据才会发送。不会上传公网/第三方服务。二维码包含本次密钥，**切勿公开截图、日志或密钥**。

## 已知限制（第一版）

- 仅 **IPv4 同局域网**（TCP `45454`），不支持互联网中转、NAT 穿透、自动设备发现，也不提供断点续传。网络中断后需重新接收，接收完成的媒体和联系人不会自动回滚；可以清理重试产生的重复项。
- 接收机建议 Android 10+（MediaStore 分区存储模式）；旧 Android 8/9 可作为发送端。
- Android 14+ 如只授予部分相册权限，传输范围受系统媒体权限约束。为了全部照片视频，须明确授予全部媒体访问。手机可能会拒绝 App 读取某些受保护媒体。
- 目前联系人只实现姓名/手机号/邮箱，重复检测按首个电话号码；如有多个联系人共用同一号码可能会被跳过。
- 部分 OPPO ROM 的 `QUERY_ALL_PACKAGES`、APK 文件读取、后台运行限制会影响应用列表或传输。
- App 拷贝不会自动恢复用户数据；包的 CPU 架构不兼容、签名不匹配、已存在同包但不同签名时，Android 安装器可能拒绝。
- 传输失败后保存的 APK 部分文件留在 App 私有目录；可以通过清除 NexMove 应用数据移除 **仅在确认不需要已接收的安装包时**。相册/联系人独立于 NexMove，清除它的数据不会撤销已经迁移的文件。
- 在 Android 15+，前台服务可能受到持续时长限制；耗时极长的传输请分批进行。
- 源代码没有经过完整第三方安全审计；当前实现没有向用户显示连接对端的身份认证信息，防止共享密钥泄露要靠当场扫码。二维码在 10 分钟内有效且只接受一次连接。
- 程序仅用于迁移自己拥有或有权迁移的数据及应用。不能迁移 DRM/收费 App 的受保护许可证。

## 工程结构

```
app/src/main/java/cn/nexmove/app/
├── MainActivity.kt                # Compose 双角色界面、二维码、权限
├── data/DeviceData.kt             # 系统媒体库、联系人、用户应用
├── data/AppInstaller.kt           # 标准 PackageInstaller（APK 分包）
├── net/SecureChannel.kt           # 本地端到端加密帧协议
└── service/TransferService.kt     # 前台服务、发送、接收、哈希校验
app/src/test/java/.../SecureChannelTest.kt    # 双向协议单元测试
```

## 建议的第一次测试

1. 新机备份已有联系人；旧机只选择 **2 张照片 + 1 个测试联系人 + 1 个不重要的 App**。
2. 确认系统相册可显示图片、联系人无乱码、APK 安装界面正常。
3. 断开 Wi-Fi 测试失败保护；确认旧手机完全没有被修改或删除。
4. 再扩大到完整相册和应用，并核对文件数量。网络故障不要在旧机上执行“删除数据”。

## 开源与隐私

本项目是按需求生成的原创示例代码，可以自行修改和继续完善；未调用任何在线服务。根目录下提供 MIT 许可证。建议正式发布前做适配测试、渗透测试，并完善错误恢复、更多联系人字段、照片原始时间戳以及增量同步。

## V1.1 新增：自动临时热点与国内/国际 ROM 兼容

升级 `versionCode=2` / `versionName=1.1.0`。

新机在“接收数据”页默认选择“自动创建专用热点”，根据 Android 版本请求 `NEARBY_WIFI_DEVICES` 或 `ACCESS_FINE_LOCATION`。启动成功后会显示临时热点 SSID、密码、含一次性加密密钥的二维码。旧机在“发送数据”页扫码，Android 10+ 会调用标准 `WifiNetworkSpecifier` 请求加入网络，必须由系统/用户批准。Android 8–9 和兼容性不足的 ColorOS/海外 ROM，可勾选“已手动加入热点”并到系统 Wi-Fi 设置连接；或者接收端关闭“自动创建热点”，返回原有同一 Wi-Fi 模式。

**临时热点不能上网是正常现象，出现“无互联网连接”不要自动断开。** 如果国产 ROM 禁止系统临时热点 API，程序不会尝试绕过安全限制或调用隐藏 API。详细测试矩阵及异常回退见 `COMPATIBILITY_V1_1.md`。
