package cn.nexmove.app.net

import android.content.Context
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.io.Closeable
import java.io.IOException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Public Android SDK only. Never modifies tethering or other apps' Wi-Fi configuration. */
object LocalHotspot {
    data class Session(
        val ssid: String,
        val passphrase: String,
        val security: String,
        private val reservation: WifiManager.LocalOnlyHotspotReservation
    ) : Closeable {
        override fun close() { reservation.close() }
    }

    /** Returns only after the temporary local-only AP is actually ready. */
    suspend fun start(context: Context, onStopped: () -> Unit = {}): Session = withTimeout(30_000) {
        suspendCancellableCoroutine { continuation ->
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val callback = object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation) {
                    try {
                        val details = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            val config = reservation.softApConfiguration
                            val security = when (config.securityType) {
                                SoftApConfiguration.SECURITY_TYPE_WPA2_PSK -> "wpa2"
                                SoftApConfiguration.SECURITY_TYPE_WPA3_SAE -> "wpa3"
                                SoftApConfiguration.SECURITY_TYPE_WPA3_SAE_TRANSITION -> "transition"
                                SoftApConfiguration.SECURITY_TYPE_OPEN -> "open"
                                else -> throw IOException("此手机生成了不兼容的热点安全类型")
                            }
                            Triple(config.ssid ?: "", config.passphrase ?: "", security)
                        } else {
                            @Suppress("DEPRECATION")
                            val config = reservation.wifiConfiguration ?: throw IOException("厂商未提供热点名称或密码")
                            Triple(config.SSID.orEmpty().trim('"'), config.preSharedKey.orEmpty().trim('"'), "wpa2")
                        }
                        if (details.first.isBlank() || (details.third != "open" && details.second.length < 8)) {
                            throw IOException("厂商没有返回有效的临时热点凭据")
                        }
                        if (continuation.isActive) continuation.resume(Session(details.first, details.second, details.third, reservation))
                        else reservation.close()
                    } catch (e: Exception) {
                        reservation.close()
                        if (continuation.isActive) continuation.resumeWithException(e)
                    }
                }
                override fun onFailed(reason: Int) {
                    if (continuation.isActive) continuation.resumeWithException(IOException("系统拒绝创建临时热点（错误码 $reason），可改用同一 Wi-Fi 模式"))
                }
                override fun onStopped() {
                    if (continuation.isActive) continuation.resumeWithException(IOException("系统停止了临时热点"))
                    else onStopped()
                }
            }
            try {
                wifi.startLocalOnlyHotspot(callback, Handler(Looper.getMainLooper()))
            } catch (e: Exception) {
                if (continuation.isActive) continuation.resumeWithException(
                    IOException("临时热点无法启动：${e.message ?: e.javaClass.simpleName}", e))
            }
        }
    }

    /** Prefer AP/softap interfaces; do not accidentally publish a VPN or cellular IP. */
    fun hotspotIpv4(): String? {
        val nets = NetworkInterface.getNetworkInterfaces() ?: return null
        val candidates = Collections.list(nets).filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }
            .flatMap { net -> Collections.list(net.inetAddresses).filterIsInstance<Inet4Address>()
                .filter { it.isSiteLocalAddress && !it.isLoopbackAddress }.map { net.name.lowercase() to it.hostAddress.orEmpty() } }
        val preferred = listOf("ap", "softap", "swlan", "wlan1", "wifi", "wlan0")
        return preferred.firstNotNullOfOrNull { prefix -> candidates.firstOrNull { (name, _) -> name.startsWith(prefix) }?.second }
            ?: candidates.firstOrNull { (name, _) -> !listOf("rmnet", "ccmni", "pdp", "tun", "wg", "v4-", "veth").any { name.startsWith(it) } }?.second
    }
}
