# NexMove 星迁 V1.1 | 兼容性与热点测试

## 实现范围

- Android 8.0+（API 26+）接收端通过公开 `WifiManager.startLocalOnlyHotspot` 创建**无互联网**临时热点；不修改系统热点设置、不使用隐藏 API、不要求 ROOT。
- Android 13+ 使用 `NEARBY_WIFI_DEVICES`；Android 8–12L 使用 `ACCESS_FINE_LOCATION`（旧系统通常还须在快速设置中打开“位置服务”）。
- Android 10+ 发送端通过 `WifiNetworkSpecifier + ConnectivityManager.requestNetwork` 申请加入指定临时热点；**系统弹窗批准是 Android 的安全要求，不能绕过**。连接 Socket 通过对应 `Network.socketFactory` 指定 Wi-Fi 网络，避免双 Wi-Fi/手机流量/代理环境路由错误。
- Android 8–9 / ColorOS 限制或不支持 WifiNetworkSpecifier：发送端可开启“已手动加入热点”，按接收端显示的 SSID/密码从系统 Wi-Fi 设置手动连接后再扫码开始。
- 如果接收端创建临时热点失败（系统拒绝、定位服务关闭、系统已有热点占用、厂商限制），取消“自动创建专用热点”，两台手机改连同一 Wi-Fi 或使用手动开启的系统热点。
- 已知 Android 10+ Wi-Fi Specifier 通常会要求系统选择和批准，而且可能为临时**局部连接**，断开后会消失，不应假定保存了系统 Wi-Fi 密码。
- 不承诺所有 ColorOS/OxygenOS/MIUI/HyperOS/FuntouchOS/EMUI 和海外系统都实现完整公开热点接口；**必须实机验证**。

## 测试矩阵（待实测）

| 新机接收端 | 旧机发送端 | 首选路径 | 回退路径 |
| --- | --- | --- | --- |
| PixelOS 17 / Android 17 / Ace 3 | OPPO ColorOS 11–16 | LOHS 自动热点，Specifier 加入 | 旧机手动加入热点；新机取消自动热点 |
| Android 13–16 AOSP/Pixel | Android 10+（含 One UI、OxygenOS、MIUI/HyperOS） | 附近设备权限 + 系统连接授权 | 系统 Wi-Fi 设置手动连接 |
| Android 8–12 | Android 8–9 | 旧定位权限 + 接收机 LOHS | 手动 Wi-Fi/路由器 |
| 国产系统拒绝 LOHS | 任意 Android | 自动模式提示系统错误码 | 同网 Wi-Fi / 手动系统热点 |
| 任一手机同时开启全局 VPN/代理 | 任意 Android | 网络专属 Socket / 无互联网热点 | 暂停 VPN 后通过手动 Wi-Fi 配对 |

## 必测项

1. 新机授予“附近的设备”权限，点击**自动创建热点并开始接收**，确认显示 SSID/密码以及二维码。
2. 旧机扫码后，Android 10+ 应出现**系统 Wi-Fi 加入确认弹窗**。允许并检查传输至少 1 张照片 + 1 联系人。
3. 旧机在 Wi-Fi 设置中连接新机热点，忽略“没有互联网”警告并保持连接；返回 NexMove 勾选“已手动加入热点”再使用配对码发送。
4. 模拟禁用系统位置服务和禁用附近设备权限；程序应显示错误，不崩溃。完成后恢复。
5. 重启试验：点“停止本次传输”，确认临时热点关闭；切后台/锁屏，确认 OEM 电池管理不杀前台数据同步服务。
6. 先测试少量数据，不要删除旧机资料；V1.1 不迁移任何应用私有数据或登录状态。

## 局限 / 已知风险

- 一些 ROM 将 Wi-Fi 接口名称设成非常规形式；当前实现按 `ap*`、`softap*`、`swlan*`、`wlan1`、`wifi*` 和 `wlan0` 的优先级寻找本地 IPv4。某些设备可能把非 AP 端口识别成热点网关，连接会超时；请使用共网回退模式并反馈日志。
- 新机可能启动并共享 WPA3-SAE 或混合模式临时热点。系统弹窗能否支持取决于旧机 Wi-Fi 驱动及 ROM。App 尝试 WPA3 或 WPA2 对应连接参数。
- 国内系统的“后台冻结”、“数据网络优化”、“无互联网断连”可能自动切断临时 Wi-Fi；请允许 NexMove 后台运行，并在 Wi-Fi 系统弹窗选择保持连接。
- 仅开放 **TCP/IPv4 45454**；暂未实现 Wi-Fi Direct P2P 自动回退、Wi-Fi 热点传输状态持久化或断点续传。
- 临时热点密码和加密密钥包含在配对二维码内，**不要公开截图或日志**。临时热点关闭后会释放占用。
- V1.1 仍是待真机验证的测试版。Android 编译成功不能说明每一种厂商 ROM 都能自动连接。
