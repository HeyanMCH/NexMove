# NexMove V1 — 设计说明

## 产品定位

双机 Android 私有数据迁移工具，优先解决无 ROOT OPPO → PixelOS 17 一加 Ace 3 的迁移。单 APK，旧机发送、新机接收。Kotlin/Compose + Android framework API，不绑定厂商生态，不依赖云。

## 工作流

```mermaid
flowchart TD
  A[新机选择接收] --> B[生成随机256位配对密钥]
  B --> C[二维码显示局域网IP和密钥]
  D[旧机选择数据] --> E[扫码获取IP和密钥]
  C --> E
  E --> F[加密通道握手]
  F --> G[传媒体和联系人]
  G --> H[传用户应用Base APK和Split APK]
  H --> I[逐文件SHA-256校验]
  I --> J[系统相册/通讯录写入]
  I --> K[PackageInstaller安装确认]
```

## 传输协议 v1

- 仅单次连接，接收服务监听 TCP/45454 10 分钟，首次连接后不再接纳其他客户端。
- 接收端每次会话用 CSPRNG 生成 32-byte secret，二维码仅局域网传播。
- 握手：4 字节 ASCII 魔数 `NXM1`，客户端 16 字节随机数，服务端 16 字节随机数。
- `salt = SHA256(clientNonce || serverNonce)`，使用 HMAC-SHA256 HKDF 风格 Extract/Expand 和方向标签派生两个独立 256bit AES 密钥。
- 双向独立 96bit nonce：固定 4 字节方向前缀 + 8 字节消息序号；每条帧 AES/GCM/NoPadding 认证。
- 帧：big-endian 4 字节加密体长度 + 帧密文（包含 16 字节 GCM tag）。最大明文 128KiB。
- 消息类型：hello/ready、manifest/ack、file/chunks/hash/ack、app_end/ack、done/ack。
- 每个文件数据流单独计算 SHA-256，与文件尾摘要比对，成功才加入相册或把 APK `.part` 重命名。

**边界：** AES-GCM 保护传输中的私密文件；二维码本身必须保密。如果另一方拿到有效二维码，就等于拿到本次的会话密钥。并未实现身份 PKI、抗已泄露配对码的主动攻击防护、断点续传或无 UI 后台配对。

## 最小数据权限

- 旧机媒体读取：Android 13+ READ_MEDIA_IMAGES / VIDEO；Android 12 及以下 READ_EXTERNAL_STORAGE。
- 旧机联系人：READ_CONTACTS。
- 新机联系人：READ_CONTACTS / WRITE_CONTACTS，用于新增和按首号码跳过重复。
- 旧机应用列表：QUERY_ALL_PACKAGES，**仅个人侧载分发，Play 上架必须满足敏感权限政策**。
- 新机 APK 安装：REQUEST_INSTALL_PACKAGES + 按 App 用户确认。
- 不要求任何设备 ROOT，不绕过 Android 应用沙盒。

## 待完善（V2）

- 复杂联系人的 vCard 完整字段、头像与联系人组。
- 照片原始 EXIF/时间排序展示一致性；增量迁移与断点续传。
- Android 14 以上的部分媒体授权更清晰地提示所选范围。
- 大容量 App 的传输进度条、存储空间检查、错误重试和批量安装状态。
- 更多 ABI / split 支持检测、已安装版本和签名对比。
- 对接端身份短码校验、协议模糊测试、恶意包安全检查。
- Android 17 及部分 OPPO ROM 的实机兼容验证。
