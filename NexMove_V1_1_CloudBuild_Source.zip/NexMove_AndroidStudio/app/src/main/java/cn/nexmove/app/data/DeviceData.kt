package cn.nexmove.app.data

import android.Manifest
import android.content.ContentProviderOperation
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.MediaStore
import android.content.ContentUris
import android.database.Cursor
import android.content.ContentValues
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Scanning is performed off the main thread. No source device root required. */
data class AppEntry(val packageName: String, val label: String, val baseApk: File, val splits: List<File>)
data class MediaEntry(val uri: Uri, val kind: String, val name: String, val mime: String, val size: Long)

data class Selection(val apps: List<String>, val photos: Boolean, val videos: Boolean, val contacts: Boolean)

object DeviceData {
    fun apps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        @Suppress("DEPRECATION")
        val installed = pm.getInstalledApplications(0)
        return installed.asSequence().filter { app ->
            app.packageName != context.packageName && app.flags and ApplicationInfo.FLAG_SYSTEM == 0
        }.mapNotNull { app ->
            val apk = File(app.sourceDir ?: "")
            if (!apk.isFile || !apk.canRead()) null else AppEntry(
                app.packageName,
                runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName),
                apk,
                app.splitSourceDirs.orEmpty().map(::File).filter { it.isFile && it.canRead() }
            )
        }.sortedBy { it.label.lowercase() }.toList()
    }

    fun media(context: Context, photos: Boolean, videos: Boolean): List<MediaEntry> {
        val result = mutableListOf<MediaEntry>()
        fun scan(collection: Uri, kind: String) {
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE)
            context.contentResolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
                val id = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val name = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val mime = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val size = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                while (cursor.moveToNext()) {
                    val bytes = cursor.getLong(size)
                    if (bytes > 0) result += MediaEntry(ContentUris.withAppendedId(collection, cursor.getLong(id)),
                        kind, cursor.getString(name) ?: "media", cursor.getString(mime) ?: "application/octet-stream", bytes)
                }
            }
        }
        if (photos) scan(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "photo")
        if (videos) scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video")
        return result
    }

    fun exportContacts(context: Context): ByteArray {
        val array = JSONArray()
        val projection = arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
        context.contentResolver.query(ContactsContract.Contacts.CONTENT_URI, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                val obj = JSONObject().put("name", cursor.getString(1) ?: "")
                val phones = JSONArray()
                context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?", arrayOf(id), null)?.use { c ->
                    while (c.moveToNext()) c.getString(0)?.let { phones.put(it) }
                }
                val emails = JSONArray()
                context.contentResolver.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS),
                    "${ContactsContract.CommonDataKinds.Email.CONTACT_ID}=?", arrayOf(id), null)?.use { c ->
                    while (c.moveToNext()) c.getString(0)?.let { emails.put(it) }
                }
                obj.put("phones", phones).put("emails", emails)
                array.put(obj)
            }
        }
        return array.toString().toByteArray(Charsets.UTF_8)
    }

    /** Deduplicate contacts by phone numbers when possible. Simple V1 model: name/phone/email. */
    fun importContacts(context: Context, bytes: ByteArray): Pair<Int, Int> {
        val array = JSONArray(String(bytes, Charsets.UTF_8))
        require(array.length() < 100000) { "Too many contacts" }
        var added = 0; var skipped = 0
        for (index in 0 until array.length()) {
            val obj = array.getJSONObject(index)
            val name = obj.optString("name").take(240)
            val phoneArray = obj.optJSONArray("phones") ?: JSONArray()
            val mailArray = obj.optJSONArray("emails") ?: JSONArray()
            val firstPhone = if (phoneArray.length() > 0) phoneArray.optString(0) else ""
            if (name.isBlank() && firstPhone.isBlank() && mailArray.length() == 0) { skipped++; continue }
            if (firstPhone.isNotBlank()) {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(firstPhone))
                val exists = context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
                    ?.use { it.moveToFirst() } ?: false
                if (exists) { skipped++; continue }
            }
            val ops = arrayListOf<ContentProviderOperation>()
            ops += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build()
            if (name.isNotBlank()) ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name).build()
            for (n in 0 until minOf(phoneArray.length(), 30)) {
                val number = phoneArray.optString(n).take(100)
                if (number.isNotBlank()) ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build()
            }
            for (n in 0 until minOf(mailArray.length(), 30)) {
                val email = mailArray.optString(n).take(240)
                if (email.isNotBlank()) ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email).build()
            }
            context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            added++
        }
        return added to skipped
    }

    /** MediaStore saves into the user's Photos/Gallery (not our private app storage). */
    fun newMedia(context: Context, kind: String, name: String, mime: String): Uri {
        require(kind == "photo" || kind == "video")
        val collection = if (kind == "photo") MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name.take(200))
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (kind == "photo") "Pictures/NexMove/" else "Movies/NexMove/")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        return context.contentResolver.insert(collection, values) ?: error("Cannot create MediaStore item")
    }
    fun finishMedia(context: Context, uri: Uri) {
        if (Build.VERSION.SDK_INT >= 29) context.contentResolver.update(uri, ContentValues().apply {
            put(MediaStore.MediaColumns.IS_PENDING, 0)
        }, null, null)
    }
}
