# NexMove 云端编译（只用手机）

当前压缩包是 Android Studio **源码工程**，不是 APK。暂时未在实际 Android SDK 下编译通过，运行 GitHub Actions 时可能需要修复编译错误。

## 云端编译方式

1. 在手机浏览器登录 https://github.com/new ，新建一个**私人仓库**，例如 `NexMove`。
2. 允许 ChatGPT 已连接的 GitHub 应用访问这个仓库，然后把仓库链接发到当前对话；如 `https://github.com/你的用户名/NexMove`。可以让 ChatGPT 帮助把源码和 `.github/workflows/build-apk.yml` 上传进去。
3. 进入仓库 → Actions → `Build NexMove APK` → `Run workflow`。
4. 构建通过后，点开本次运行，在 Artifacts 下下载 `NexMove-v1-debug-APK.zip`，解压后得到 `app-debug.apk`。
5. 两台 Android 手机装**同一个** APK，首次安装若有系统提示需要手动允许。

注意：GitHub 的 Actions 可能受仓库权限、账单和使用额度约束。仓库源码不包含你的手机实际相册、联系人或个人数据；但不要上传个人真实备份或配对码。

## 编译配置

- GitHub Actions: Ubuntu, JDK 17, Android SDK 35, Gradle 8.11.1
- Kotlin 2.1.20, Android Gradle Plugin 8.9.2
- APK 类型：**debug**（调试签名，不适合上架；每次不同构建环境生成的调试签名可能变化）
- 安装兼容目标：Android 8.0（API 26）及以上；最高目标为 API 35，Android 17 的实际兼容性尚未验证

## 安全

默认只通过同一局域网连接；不依赖 Root；不迁移应用私有数据或登录状态。保存原设备数据，先以少量文件和测试联系人验证再批量迁移。

## V1.1 通过现有 GitHub 仓库自动编译

仓库：https://github.com/HeyanMCH/NexMove

1. 将当前 ZIP 原样以 `NexMove_V1_1_CloudBuild_Source.zip` 上传到 `main` 分支根目录（不要解压）；旧版 ZIP 可以保留作回滚。
2. 用源码包同级给出的 `NexMove_build_v1_1.yml` 内容更新仓库中的 `.github/workflows/build-apk.yml`（已经更新的仓库可略过）。
3. 在 Actions 页等待 `Build NexMove Android APK` 成功，在 Artifacts 下载 `NexMove-v1.1-debug-apk`，解压后得到 `app-debug.apk`。
4. 调试版可能使用与 V1 不同的签名，若无法覆盖安装请先确认 NexMove 内已接收 APK 备份后再卸载旧版。不要清除旧 OPPO 数据。
