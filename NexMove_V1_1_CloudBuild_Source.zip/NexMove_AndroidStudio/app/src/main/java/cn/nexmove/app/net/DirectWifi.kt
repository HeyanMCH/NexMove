package cn.nexmove.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.io.Closeable
import java.io.IOException
import java.net.Socket
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Android 10+: OS-mediated Wi-Fi join; user approval is not bypassed. */
object DirectWifi {
    data class Session(val network: Network, private val manager: ConnectivityManager,
                       private val callback: ConnectivityManager.NetworkCallback) : Closeable {
        fun socket(): Socket = network.socketFactory.createSocket()
        override fun close() { runCatching { manager.unregisterNetworkCallback(callback) } }
    }

    suspend fun join(context: Context, ssid: String, passphrase: String, security: String): Session {
        require(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { "旧系统请使用 Wi-Fi 设置手动加入" }
        require(ssid.isNotBlank()) { "热点 SSID 为空" }
        val builder = WifiNetworkSpecifier.Builder().setSsid(ssid)
        when (security) {
            "wpa3" -> builder.setWpa3Passphrase(passphrase)
            "transition", "wpa2" -> builder.setWpa2Passphrase(passphrase)
            "open" -> Unit
            else -> throw IOException("此热点安全类型不支持自动配对")
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(builder.build())
            .build()
        val manager = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return withTimeout(60_000) {
            suspendCancellableCoroutine { continuation ->
                val callback = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        if (continuation.isActive) continuation.resume(Session(network, manager, this))
                        else runCatching { manager.unregisterNetworkCallback(this) }
                    }
                    override fun onUnavailable() {
                        if (continuation.isActive) continuation.resumeWithException(
                            IOException("系统未允许或无法加入热点；可先手动连接 Wi-Fi 后重试"))
                        runCatching { manager.unregisterNetworkCallback(this) }
                    }
                }
                continuation.invokeOnCancellation { runCatching { manager.unregisterNetworkCallback(callback) } }
                try {
                    manager.requestNetwork(request, callback, 55_000)
                } catch (e: Exception) {
                    if (continuation.isActive) continuation.resumeWithException(
                        IOException("连接热点失败：${e.message ?: e.javaClass.simpleName}", e))
                }
            }
        }
    }
}
