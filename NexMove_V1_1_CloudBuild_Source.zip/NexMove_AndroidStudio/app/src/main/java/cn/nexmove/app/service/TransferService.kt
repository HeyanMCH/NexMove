package cn.nexmove.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Base64
import androidx.core.app.NotificationCompat
import cn.nexmove.app.data.AppInstaller
import cn.nexmove.app.data.DeviceData
import cn.nexmove.app.data.Selection
import cn.nexmove.app.net.SecureChannel
import cn.nexmove.app.net.LocalHotspot
import cn.nexmove.app.net.DirectWifi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/** Only a status channel to the UI. Never persist or upload the pairing secret. */
data class TransferStatus(val mode: String = "idle", val message: String = "准备就绪",
    val pairing: String = "", val completed: Int = 0, val errors: Int = 0,
    val hotspotSsid: String = "", val hotspotPassword: String = "")
object TransferHub {
    private val _status = MutableStateFlow(TransferStatus())
    val status: StateFlow<TransferStatus> = _status
    fun update(value: TransferStatus) { _status.value = value }
    fun notice(message: String) { _status.value = _status.value.copy(message = message) }
    fun tick(message: String) { _status.value = _status.value.copy(message = message, completed = _status.value.completed + 1) }
    fun error(message: String) { _status.value = _status.value.copy(message = message, errors = _status.value.errors + 1) }
}

class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var listener: ServerSocket? = null
    @Volatile private var active: Socket? = null
    private val cancelled = AtomicBoolean(false)
    @Volatile private var temporaryHotspot: LocalHotspot.Session? = null

    companion object {
        const val RECEIVE = "cn.nexmove.RECEIVE"
        const val SEND = "cn.nexmove.SEND"
        const val CANCEL = "cn.nexmove.CANCEL"
        private const val CHANNEL = "nexmove_transfer"
        fun start(context: Context, intent: Intent) = androidx.core.content.ContextCompat.startForegroundService(context, intent)
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(CHANNEL, "NexMove 数据传输", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == CANCEL) {
            cancelled.set(true); job?.cancel()
            runCatching { active?.close() }; runCatching { listener?.close() }
            runCatching { temporaryHotspot?.close() }; temporaryHotspot = null
            TransferHub.update(TransferHub.status.value.copy(mode = "idle", pairing = "",
                hotspotSsid = "", hotspotPassword = "", message = "已取消传输"))
            stopSelf(); return START_NOT_STICKY
        }
        if (job?.isActive == true) return START_NOT_STICKY
        cancelled.set(false)
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("NexMove 星迁").setContentText("正在等待或传输数据，请保持 Wi-Fi 连接")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(100, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(100, notification)
        job = scope.launch {
            try {
                when (intent?.action) {
                    RECEIVE -> receive(intent.getBooleanExtra("auto_hotspot", false))
                    SEND -> send(requireNotNull(intent))
                    else -> Unit
                }
            } catch (e: Exception) {
                if (!cancelled.get()) TransferHub.error("传输中断：${e.message ?: e.javaClass.simpleName}")
            } finally {
                runCatching { active?.close() }; active = null
                runCatching { listener?.close() }; listener = null
                runCatching { temporaryHotspot?.close() }; temporaryHotspot = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                TransferHub.update(TransferHub.status.value.copy(mode = "idle", pairing = "",
                    hotspotSsid = "", hotspotPassword = ""))
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun receive(autoHotspot: Boolean) {
        val hotspot = if (autoHotspot) {
            TransferHub.update(TransferStatus("receive", "正在申请临时热点，请确认附近设备权限…"))
            LocalHotspot.start(this) {
                TransferHub.error("系统关闭了临时热点，请改用同一 Wi-Fi 或重新创建")
                runCatching { listener?.close() }
            }.also { temporaryHotspot = it }
        } else null
        // AP interfaces may be created asynchronously, especially on OEM Android forks.
        var ip: String? = null
        repeat(if (hotspot != null) 20 else 1) {
            if (ip == null) {
                ip = if (hotspot != null) LocalHotspot.hotspotIpv4() else localIpv4()
                if (ip == null) kotlinx.coroutines.delay(300)
            }
        }
        val address = ip ?: error("未检测到可用于局域网传输的 IPv4 地址，请尝试手动 Wi-Fi 模式")
        val key = SecureChannel.randomSecret()
        val keyText = Base64.encodeToString(key, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        val builder = Uri.Builder().scheme("nexmove").authority("pair")
            .appendQueryParameter("ip", address)
            .appendQueryParameter("port", SecureChannel.PORT.toString())
            .appendQueryParameter("key", keyText)
        if (hotspot != null) {
            builder.appendQueryParameter("ssid", hotspot.ssid)
                .appendQueryParameter("pw", hotspot.passphrase)
                .appendQueryParameter("sec", hotspot.security)
        }
        val pairing = builder.build().toString()
        ServerSocket(SecureChannel.PORT).use { server ->
            listener = server
            server.soTimeout = 600_000
            TransferHub.update(TransferStatus("receive", "等待发送手机扫描二维码（10 分钟有效）", pairing,
                hotspotSsid = hotspot?.ssid.orEmpty(), hotspotPassword = hotspot?.passphrase.orEmpty()))
            // Only one connection attempt/session: no PIN guessing loop.
            server.accept().use { socket ->
                active = socket; socket.soTimeout = 90_000; socket.tcpNoDelay = true
                val channel = SecureChannel.server(socket.getInputStream(), socket.getOutputStream(), key)
                TransferHub.notice("加密连接成功，正在接收…")
                receiveLoop(channel)
                TransferHub.notice("接收结束！可在下方逐个安装应用")
            }
        }
    }

    private fun receiveLoop(channel: SecureChannel) {
        while (!cancelled.get()) {
            val header = channel.recvJson()
            when (header.optString("type")) {
                "manifest" -> {
                    TransferHub.notice("准备接收：${header.optInt("files")} 个媒体文件，${header.optInt("apps")} 个应用")
                    channel.sendJson(JSONObject().put("ok", true))
                }
                "file" -> {
                    val kind = header.getString("kind")
                    val size = header.getLong("size")
                    require(size in 0..(100L * 1024 * 1024 * 1024)) { "File is too large" }
                    val displayName = header.optString("name").substringAfterLast('/').substringAfterLast('\\').take(180)
                    require(displayName.isNotBlank())
                    val name = if (kind == "apk") header.getString("part") else displayName
                    var temporary: File? = null
                    var mediaUri: Uri? = null
                    try {
                        val output: OutputStream = when (kind) {
                            "photo", "video" -> {
                                mediaUri = DeviceData.newMedia(this, kind, displayName, header.getString("mime"))
                                contentResolver.openOutputStream(mediaUri!!, "w") ?: error("Cannot open MediaStore")
                            }
                            "apk" -> {
                                val pkg = header.getString("package")
                                require(Regex("[a-zA-Z0-9_.]{3,200}").matches(pkg) && pkg.contains('.'))
                                require(name == "base.apk" || Regex("split_[A-Za-z0-9_.-]{1,160}\\.apk").matches(name))
                                val dir = AppInstaller.appDir(this, pkg)
                                temporary = File(dir, "$name.part")
                                AppInstaller.saveMeta(dir, header.optString("label", pkg))
                                temporary!!.outputStream()
                            }
                            "contacts" -> {
                                require(size < 32L * 1024 * 1024) { "Contacts payload too large" }
                                ByteArrayOutputStream()
                            }
                            else -> error("Unknown transfer kind")
                        }
                        val digest = MessageDigest.getInstance("SHA-256")
                        var remaining = size
                        output.use { out ->
                            while (remaining > 0L) {
                                val bytes = channel.recv()
                                if (bytes.isEmpty() || bytes.size.toLong() > remaining) error("Invalid file chunk")
                                out.write(bytes); digest.update(bytes); remaining -= bytes.size
                            }
                        }
                        val footer = channel.recvJson()
                        check(footer.optString("type") == "sha256" &&
                            footer.optString("hash") == SecureChannel.hex(digest.digest())) { "SHA-256 不匹配" }
                        when (kind) {
                            "photo", "video" -> DeviceData.finishMedia(this, mediaUri!!)
                            "apk" -> {
                                val file = File(temporary!!.parentFile, name)
                                check(temporary!!.renameTo(file)) { "APK file rename failed" }
                            }
                            "contacts" -> {
                                val bytes = (output as ByteArrayOutputStream).toByteArray()
                                val (added, skipped) = DeviceData.importContacts(this, bytes)
                                TransferHub.notice("联系人导入 $added 条，跳过重复 $skipped 条")
                            }
                        }
                        channel.sendJson(JSONObject().put("ok", true))
                        TransferHub.tick("已接收：$displayName ($kind)")
                    } catch (e: Exception) {
                        mediaUri?.let { runCatching { contentResolver.delete(it, null, null) } }
                        temporary?.delete()
                        runCatching { channel.sendJson(JSONObject().put("ok", false).put("message", e.message ?: "接收失败")) }
                        throw e
                    }
                }
                "app_end" -> {
                    val pkg = header.getString("package")
                    File(AppInstaller.appDir(this, pkg), "complete.flag").writeText("ok")
                    channel.sendJson(JSONObject().put("ok", true))
                }
                "done" -> {
                    channel.sendJson(JSONObject().put("ok", true))
                    return
                }
                else -> error("Unknown frame type")
            }
        }
    }

    private suspend fun send(intent: Intent) {
        val address = intent.getStringExtra("pairing") ?: error("No pairing information")
        val uri = Uri.parse(address)
        check(uri.scheme == "nexmove" && uri.host == "pair") { "配对码格式错误" }
        val ip = uri.getQueryParameter("ip") ?: error("Missing IP")
        // Reject arbitrary DNS names to limit accidental remote uploads.
        check(Regex("(?:\\d{1,3}\\.){3}\\d{1,3}").matches(ip) && java.net.InetAddress.getByName(ip).isSiteLocalAddress) { "Only LAN IPv4 is accepted" }
        val key = Base64.decode(uri.getQueryParameter("key") ?: "", Base64.URL_SAFE or Base64.NO_PADDING)
        check(key.size == 32)
        val selection = Selection(intent.getStringArrayListExtra("apps").orEmpty(),
            intent.getBooleanExtra("photos", true), intent.getBooleanExtra("videos", true),
            intent.getBooleanExtra("contacts", true))
        TransferHub.update(TransferStatus("send", "正在准备连接…"))
        // Android 10+ joins via WifiNetworkSpecifier; platform/OEM approval remains mandatory.
        // Android 8/9 and restrictive OEMs can use Settings > Wi-Fi and retry in manual mode.
        val ssid = uri.getQueryParameter("ssid")
        val manualWifi = intent.getBooleanExtra("manual_wifi", false)
        val direct = if (!ssid.isNullOrBlank() && !manualWifi && Build.VERSION.SDK_INT >= 29) {
            TransferHub.notice("请在系统对话框中确认连接 NexMove 临时热点…")
            DirectWifi.join(this, ssid, uri.getQueryParameter("pw").orEmpty(),
                uri.getQueryParameter("sec") ?: "wpa2")
        } else null
        try {
        TransferHub.notice("正在搜索文件和应用…")
        val media = DeviceData.media(this, selection.photos, selection.videos)
        val apps = DeviceData.apps(this).filter { it.packageName in selection.apps }
        (direct?.socket() ?: Socket()).use { socket ->
            socket.connect(java.net.InetSocketAddress(ip, SecureChannel.PORT), 15_000)
            active = socket; socket.soTimeout = 90_000; socket.tcpNoDelay = true
            val channel = SecureChannel.client(socket.getInputStream(), socket.getOutputStream(), key)
            channel.sendJson(JSONObject().put("type", "manifest").put("files", media.size)
                .put("apps", apps.size).put("contacts", selection.contacts))
            ack(channel)
            for ((index, item) in media.withIndex()) {
                if (cancelled.get()) break
                TransferHub.notice("正在传照片视频 ${index + 1}/${media.size}：${item.name}")
                val stream = contentResolver.openInputStream(item.uri) ?: error("Cannot read ${item.uri}")
                stream.use { sendFile(channel, "file", item.kind, item.name, item.mime, item.size, it) }
            }
            if (selection.contacts && !cancelled.get()) {
                TransferHub.notice("正在迁移联系人…")
                val bytes = DeviceData.exportContacts(this)
                sendFile(channel, "file", "contacts", "contacts.json", "application/json", bytes.size.toLong(),
                    ByteArrayInputStream(bytes))
            }
            for ((index, app) in apps.withIndex()) {
                if (cancelled.get()) break
                TransferHub.notice("正在传应用 ${index + 1}/${apps.size}：${app.label}")
                val files = listOf(app.baseApk) + app.splits
                for ((partIndex, f) in files.withIndex()) {
                    val part = if (partIndex == 0) "base.apk" else "split_${partIndex}.apk"
                    f.inputStream().use { sendFile(channel, "file", "apk", app.label, "application/vnd.android.package-archive", f.length(), it,
                        JSONObject().put("package", app.packageName).put("label", app.label).put("part", part)) }
                }
                channel.sendJson(JSONObject().put("type", "app_end").put("package", app.packageName)); ack(channel)
            }
            if (!cancelled.get()) {
                channel.sendJson(JSONObject().put("type", "done")); ack(channel)
                TransferHub.notice("全部发送完成")
            }
        }
        } finally { direct?.close() }
    }

    private fun sendFile(channel: SecureChannel, type: String, kind: String, name: String,
                         mime: String, size: Long, stream: InputStream, extra: JSONObject = JSONObject()) {
        val header = extra.put("type", type).put("kind", kind).put("name", name)
            .put("mime", mime).put("size", size)
        channel.sendJson(header)
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        var remaining = size
        while (remaining > 0) {
            val read = stream.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            if (read == -1) error("Source file ended early: $name")
            if (read == 0) continue
            digest.update(buffer, 0, read)
            channel.send(buffer.copyOf(read))
            remaining -= read
        }
        channel.sendJson(JSONObject().put("type", "sha256").put("hash", SecureChannel.hex(digest.digest())))
        ack(channel)
        TransferHub.tick("已发送：$name")
    }
    private fun ack(channel: SecureChannel) {
        val result = channel.recvJson()
        check(result.optBoolean("ok", false)) { "接收端拒绝：${result.optString("message")}" }
    }
    private fun localIpv4(): String? {
        val networks = NetworkInterface.getNetworkInterfaces() ?: return null
        val entries = java.util.Collections.list(networks)
            .filter { it.isUp && !it.isLoopback }
            .flatMap { net -> java.util.Collections.list(net.inetAddresses).map { net.name to it } }
            .filter { (_, addr) -> addr is Inet4Address && addr.isSiteLocalAddress }
        return entries.firstOrNull { it.first.startsWith("wlan") || it.first.startsWith("swlan") }
            ?.second?.hostAddress ?: entries.firstOrNull()?.second?.hostAddress
    }
    override fun onDestroy() { super.onDestroy(); cancelled.set(true); scope.cancel() }
}
